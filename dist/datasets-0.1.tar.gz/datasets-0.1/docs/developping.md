# Developing 

To develop the main library, clone this repository and, from the main directory, use

```
pip install -e .
```

to install the command line tool and develop at the same time.