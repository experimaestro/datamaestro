# Datasets

This projects aims at grouping utilities to deal with the numerous and heterogenous datasets present on the Web. It aims
at being

1. A reference for available resources
1. A tool to automatically download and/or process resources, when this is possible

Each dataset is uniquely identified by a qualified name such as `nist.trec.2009.web.adhoc`. A dataset can reference other
datasets.

This software integrates with the [experimaestro](http://experimaestro.sf.net) experiment manager.